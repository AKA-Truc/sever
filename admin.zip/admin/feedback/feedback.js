//ràng buộc token
document.addEventListener('DOMContentLoaded', function() {
    const accessToken = sessionStorage.getItem('accessToken');
    
    if (!accessToken) {
        window.location.href = '../Login/login.html';
    }
});